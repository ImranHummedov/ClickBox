## Prompt 1
Your task is to build a drum kit app using HTML, CSS, and JavaScript.
Start with one button representing a drum sound: kick. 
Center the button in the middle of the screen. 
When the button is clicked, the kick drum sound should play.

I have provided you with a "kick.wav" file for the drum sound in a "sounds" folder.
Use an audio element in the HTML to pre-load the sound file. 

Remember to add comments to your HTML and JavaScript code to help me understand
what each part is doing.