document.getElementById('play-button').addEventListener('click', startGame);
let score = 0;
let activeSquare = null;
let gameInterval;
let timeout;
let countdownInterval;

function startGame() {
    resetGame();
    activateSquare();

    countdownInterval = setInterval(updateTimer, 1000);
    timeout = setTimeout(endGame, 20000); // 20 second timer
}

function resetGame() {
    score = 0;
    document.getElementById('score').textContent = '0';
    document.getElementById('timer').textContent = '20';
    if (timeout) clearTimeout(timeout);
    if (gameInterval) clearInterval(gameInterval);
    if (countdownInterval) clearInterval(countdownInterval);
}

function activateSquare() {
    if (activeSquare) activeSquare.removeEventListener('click', squareClicked);
    const squares = document.querySelectorAll('.square');
    const index = Math.floor(Math.random() * squares.length);
    squares.forEach(square => square.style.backgroundColor = '#0000ff'); // Reset all squares
    activeSquare = squares[index];
    activeSquare.style.backgroundColor = 'red';
    activeSquare.addEventListener('click', squareClicked);
}

function squareClicked(event) {
    if (event.target === activeSquare) {
        score++;
        document.getElementById('score').textContent = score.toString();
        activateSquare();
    }
}

function updateTimer() {
    let currentTime = parseInt(document.getElementById('timer').textContent, 10);
    currentTime--;
    document.getElementById('timer').textContent = currentTime.toString();

    if (currentTime <= 0) {
        clearInterval(countdownInterval);
    }
}

function endGame() {
    clearInterval(countdownInterval);
    alert('Game Over. Your score is: ' + score);
    resetGame();
}
